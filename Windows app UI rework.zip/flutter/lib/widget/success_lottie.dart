import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class SuccessLottie extends StatelessWidget {
  final String path;
  final String message;
  final double size;

  const SuccessLottie({
    super.key,
    this.message = AppStrings.successful,
    this.size = 200,
    required this.path,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Lottie.asset(path, width: size, height: size, repeat: false),
        const SizedBox(height: 16),
        Text(
          message,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: ColorManger.primary,
          ),
        ),
      ],
    );
  }
}
