import 'package:data_logger/core/corlor_manger.dart';
// ignore_for_file: deprecated_member_use

import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:flutter/material.dart';

class HowToUse extends StatelessWidget {
  HowToUse({super.key});

  @override
  Widget build(BuildContext context) {
    final howToUseSteps = [
      {
        'icon': Icons.download,
        'title': AppStrings.downloadConnectionDefinitions.tr(context),
        'subtitle': AppStrings.toConnectTheDeviceProperly.tr(context),
        'isDriver': true,
      },
      {
        'icon': Icons.touch_app,
        'title': AppStrings.pressAndHoldTitle.tr(context),
        'subtitle': AppStrings.pressAndHoldSubtitle.tr(context),
      },
      {
        'icon': Icons.usb,
        'title': AppStrings.connectCableTitle.tr(context),
        'subtitle': AppStrings.connectCableSubtitle.tr(context),
      },

      {
        'icon': Icons.usb_rounded,
        'title': AppStrings.clickConnectTitle.tr(context),
        'subtitle': AppStrings.clickConnectSubtitle.tr(context),
      },
      {
        'icon': Icons.data_usage,
        'title': AppStrings.clickReadDataTitle.tr(context),
        'subtitle': AppStrings.clickReadDataSubtitle.tr(context),
      },
    ];
    final theme = Theme.of(context);
    return Center(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 800),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                AppStrings.followStepsToGetStarted.tr(context),
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),

              ...howToUseSteps.asMap().entries.map((entry) {
                final index = entry.key + 1;
                final step = entry.value;

                return Container(
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(
                        backgroundColor: theme.primaryColor.withOpacity(0.1),
                        child: Text(
                          '$index',
                          style: TextStyle(
                            color: ColorManger.primary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Icon(step['icon'] as IconData, color: ColorManger.primary),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              step['title'] as String,
                              style: theme.textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            Text(
                              step['subtitle'] as String,
                              style: theme.textTheme.bodyMedium,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}
