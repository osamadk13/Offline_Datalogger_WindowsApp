import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/view_model/datalogger_provider.dart';
import 'package:data_logger/widget/logger_info.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class Sidebar extends ConsumerWidget {
  final Function(int) onItemSelected;
  final int selectedIndex;

  const Sidebar({
    super.key,
    required this.onItemSelected,
    required this.selectedIndex,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loggerInfoProvider = ref.watch(statsLoggerInfoProvider);
    final items = [
      {'icon': Icons.show_chart, 'label': AppStrings.view.tr(context)},
      {'icon': Icons.analytics, 'label': AppStrings.dataAnalysis.tr(context)},
      {'icon': Icons.settings, 'label': AppStrings.settings.tr(context)},
      {
        'icon': Icons.contact_mail_outlined,
        'label': AppStrings.contactUs.tr(context),
      },
    ];

    return Container(
      width: 220,
      height: MediaQuery.of(context).size.height,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Color(0xFFE0E0E0), width: 1.5),
      ),

      child: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 40),
            Image.asset('assets/images/atmoslink_horizontal.png', width: 170),
            const SizedBox(height: 40),
            for (int i = 0; i < items.length; i++)
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8.0,
                  vertical: 4,
                ),
                child: GestureDetector(
                  onTap: () => onItemSelected(i),
                  child: Container(
                    decoration: BoxDecoration(
                      color:
                          selectedIndex == i
                              ? ColorManger.primaryLight
                              : Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color:
                            selectedIndex == i
                                ? ColorManger.primary
                                : Colors.transparent,
                        width: 1,
                      ),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    child: Row(
                      children: [
                        Icon(
                          items[i]['icon'] as IconData,
                          color:
                              selectedIndex == i ? ColorManger.primary : Colors.black,
                        ),
                        const SizedBox(width: 10),
                        Text(
                          items[i]['label'] as String,
                          style: TextStyle(
                            color:
                                selectedIndex == i ? ColorManger.primary : Colors.black,
                            fontWeight:
                                selectedIndex == i
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            loggerInfoProvider.count == 0
                ? const SizedBox.shrink()
                : LoggerInfo(),
          ],
        ),
      ),
    );
  }
}
