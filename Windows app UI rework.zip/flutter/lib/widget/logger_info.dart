import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/view_model/datalogger_provider.dart';
import 'package:data_logger/view_model/language_provider.dart';
import 'package:data_logger/view_model/log_interval_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

class LoggerInfo extends ConsumerWidget {
  const LoggerInfo({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(languageProvider).locale;

    final loggerInfoProvider = ref.watch(statsLoggerInfoProvider);
    final logInterval = ref.watch(logIntervalProvider);
    const int totalCapacity = 5330;
    return Column(
      children: [
        SizedBox(height: 60),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.analytics, size: 18, color: ColorManger.primary),
                  SizedBox(width: 6),
                  Text(
                    AppStrings.loggerInfo.tr(context),
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),

              _miniStat(
                AppStrings.totalCapacity.tr(context),
                totalCapacity.toString(),
                Icons.check_circle,
              ),
              _miniStat(
                AppStrings.totalReadings.tr(context),
                loggerInfoProvider.count.toString(),
                Icons.check_circle,
              ),
              _miniStat(
                AppStrings.remainingReadings.tr(context),
                (totalCapacity - loggerInfoProvider.count).toString(),
                Icons.check_circle,
              ),

              _miniStat(
                AppStrings.moduleID.tr(context),
                loggerInfoProvider.moduleId.toString(),
                Icons.timelapse,
              ),
              _miniStat(
                AppStrings.logInterval.tr(context),
                "${loggerInfoProvider.timeInterval} Min",
                Icons.timelapse,
              ),
              _miniStat(
                AppStrings.maxTemp.tr(context),
                "${loggerInfoProvider.maxTemperature.toString()} °C",
                Icons.thermostat,
              ),
              _miniStat(
                AppStrings.maxRH.tr(context),
                "${loggerInfoProvider.maxHumidity.toString()} %",
                Icons.water_drop,
              ),
              _miniStat(
                AppStrings.minTemp.tr(context),
                "${loggerInfoProvider.minTemperature.toString()} °C",
                Icons.thermostat,
              ),
              _miniStat(
                AppStrings.minRH.tr(context),
                "${loggerInfoProvider.minHumidity.toString()} %",
                Icons.water_drop,
              ),
              _miniStat(
                AppStrings.averageTemp.tr(context),
                "${loggerInfoProvider.avgTemperature.toStringAsFixed(3)} °C",
                Icons.thermostat,
              ),
              _miniStat(
                AppStrings.averageRH.tr(context),
                "${loggerInfoProvider.avgHumidity.toStringAsFixed(3)} %",
                Icons.water_drop,
              ),
              _miniStat(
                AppStrings.first.tr(context),
                formatDateTimeByLocaleWithoutSeconds(
                  loggerInfoProvider.firstReading,
                  locale.languageCode,
                ),
                // formatDate(loggerInfoProvider.firstReading),
                Icons.calendar_today,
              ),
              _miniStat(
                AppStrings.last.tr(context),
                formatDateTimeByLocaleWithoutSeconds(
                  loggerInfoProvider.lastReading,
                  locale.languageCode,
                ),
                Icons.event_note,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

Widget _miniStat(String label, String value, IconData icon) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        Icon(icon, size: 14, color: ColorManger.primary),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(fontSize: 12, color: Colors.black87),
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.black,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    ),
  );
}

String formatDateTimeByLocaleWithoutSeconds(
  DateTime dateTime,
  String languageCode,
) {
  final raw = DateFormat("yyyy-MM-dd hh:mm a").format(dateTime);

  if (languageCode == "ar") {
    return raw.replaceAll("AM", "صباحًا").replaceAll("PM", "مساءً");
  }

  return raw;
}
