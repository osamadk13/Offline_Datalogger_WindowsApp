import 'dart:io';
import 'dart:ui' as ui;
import 'package:data_logger/view_model/datalogger_provider.dart';
import 'package:data_logger/view_model/log_interval_provider.dart';
import 'package:data_logger/widget/formate_date.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:open_file/open_file.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

Future<void> exportChartToPdf(GlobalKey key, WidgetRef ref) async {
  try {
    final boundary =
        key.currentContext!.findRenderObject() as RenderRepaintBoundary;
    final image = await boundary.toImage(pixelRatio: 3.0);
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    final pngBytes = byteData!.buffer.asUint8List();

    final pdf = PdfDocument();
    final page = pdf.pages.add();

    final loggerInfo = ref.read(statsLoggerInfoProvider);
    final logInterval = ref.read(logIntervalProvider);

    double y = 0;
    final PdfGrid grid = PdfGrid();

    grid.columns.add(count: 2);

    // تنسيق الجدول
    grid.style = PdfGridStyle(
      font: PdfStandardFont(PdfFontFamily.helvetica, 10),
      cellPadding: PdfPaddings(left: 4, right: 4, top: 2, bottom: 2),
      borderOverlapStyle: PdfBorderOverlapStyle.overlap,
    );

    // تضيف الصفوف + الداتا
    void addRow(String label, String value) {
      final row = grid.rows.add();
      row.cells[0].value = label;
      row.cells[1].value = value;
    }

    // هنا تحط البيانات بدل drawString:
    // زيادة المسافة قبل العنوان
    y += 20;

    // إعداد تنسيق النص (توسيط + محاذاة رأسية)
    final PdfStringFormat format = PdfStringFormat(
      alignment: PdfTextAlignment.center,
      lineAlignment: PdfVerticalAlignment.middle,
    );

    // رسم خلفية مستطيل خفيف أسفل العنوان (اختياري)
    page.graphics.drawRectangle(
      brush: PdfSolidBrush(PdfColor(230, 230, 250)), // لون خلفية فاتح Lavender
      bounds: Rect.fromLTWH(0, y, page.getClientSize().width, 30),
    );

    // رسم النص "Chart" في المنتصف
    page.graphics.drawString(
      "Data Logger Info",
      PdfStandardFont(PdfFontFamily.helvetica, 18, style: PdfFontStyle.bold),
      brush: PdfSolidBrush(PdfColor(44, 62, 80)), // لون غامق أنيق
      bounds: Rect.fromLTWH(0, y, page.getClientSize().width, 30),
      format: format,
    );

    y += 50;
    addRow("Total Readings", loggerInfo.count.toString());
    addRow("Module ID", loggerInfo.moduleId.toString());
    addRow("Log Interval", "${logInterval.toString()} Min");
    addRow("Max Temprature", "${loggerInfo.maxTemperature} °C");
    addRow("Max Humidity", "${loggerInfo.maxHumidity} %");
    addRow("Min Temprature", "${loggerInfo.minTemperature} °C");
    addRow("Min Humidity", "${loggerInfo.minHumidity} %");
    addRow("Average Temprature", loggerInfo.avgTemperature.toStringAsFixed(3));
    addRow("Average Humidity", loggerInfo.avgHumidity.toStringAsFixed(3));
    addRow("First Time Reading", formatDate(loggerInfo.firstReading));
    addRow("Last Time Reading", formatDate(loggerInfo.lastReading));

    // تنسيق الأعمدة
    grid.columns[0].width = page.getClientSize().width / grid.columns.count;
    grid.columns[1].width = page.getClientSize().width / grid.columns.count;

    for (int i = 0; i < grid.rows.count; i++) {
      grid.rows[i].cells[0].style = PdfGridCellStyle(
        font: PdfStandardFont(
          PdfFontFamily.helvetica,
          10,
          style: PdfFontStyle.bold,
        ),
      );
    }
    final PdfLayoutResult result =
        grid.draw(
          page: page,
          bounds: Rect.fromLTWH(0, y, page.getClientSize().width, 0),
        )!;
    y = result.bounds.bottom + 15;
    ///////////////////////////////////////////////////////////////////////////
    // Chart
    page.graphics.drawRectangle(
      brush: PdfSolidBrush(PdfColor(230, 230, 250)),
      bounds: Rect.fromLTWH(0, y, page.getClientSize().width, 30),
    );
    page.graphics.drawString(
      "Chart Report",
      PdfStandardFont(PdfFontFamily.helvetica, 18, style: PdfFontStyle.bold),
      brush: PdfSolidBrush(PdfColor(44, 62, 80)), // لون غامق أنيق
      bounds: Rect.fromLTWH(0, y, page.getClientSize().width, 30),
      format: format,
    );
    final pageWidth = page.getClientSize().width;
    final imageWidth = pageWidth; // استخدم عرض الصفحة بالكامل
    final aspectRatio = image.width / image.height;
    final imageHeight = imageWidth / aspectRatio;

    y = result.bounds.bottom + 60;
    final imageElement = PdfBitmap(pngBytes);
    page.graphics.drawImage(
      imageElement,
      Rect.fromLTWH(0, y, imageWidth, imageHeight),
    );
    // page.graphics.drawImage(imageElement, Rect.fromLTWH(0, y, 550, 300));
    y = result.bounds.bottom + 60;

    ///////////////////////////////////////////////////////////////////////////
    // Logo
    Future<PdfBitmap> readImageData(String path) async {
      final data = await rootBundle.load(path);
      return PdfBitmap(data.buffer.asUint8List());
    }

    final dkImage = await readImageData('assets/images/atmoslink_stacked.png');

    final pageSize = page.getClientSize();
    const double imgWidth = 120;
    const double imgHeight = 67;

    page.graphics.drawImage(
      dkImage,
      Rect.fromLTWH(
        (pageSize.width - imgWidth) / 2,
        y + 320,
        imgWidth,
        imgHeight,
      ),
    );
    ///////////////////////////////////////////////////////////////////////////
    final bytes = await pdf.save();

    final now = DateTime.now();
    final formattedDate = DateFormat('yyyyMMdd_HHmmss').format(now);
    final defaultFileName = 'chart_export_$formattedDate.pdf';

    final savePath = await FilePicker.platform.saveFile(
      dialogTitle: 'Save Chart as PDF',
      fileName: defaultFileName,
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (savePath != null) {
      final file = File(savePath);
      await file.writeAsBytes(bytes);
      await OpenFile.open(file.path);
    } else {
      debugPrint('❌ User cancelled saving the file.');
    }
  } catch (e) {
    debugPrint("❌ Error exporting chart to PDF: $e");
  }
}
