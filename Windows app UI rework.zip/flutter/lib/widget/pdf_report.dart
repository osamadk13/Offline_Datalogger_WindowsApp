import 'package:data_logger/core/corlor_manger.dart';
// ignore_for_file: use_build_context_synchronously

import 'dart:io';
import 'dart:typed_data';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/model/model.dart';
import 'package:data_logger/view_model/datalogger_provider.dart';
import 'package:data_logger/widget/success_lottie.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart';

class ExportPage extends ConsumerWidget {
  const ExportPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final messages = ref.watch(parsedMessagesProvider);
    return Center(
      child: SizedBox(
        height: 55.h,
        child: ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            foregroundColor: ColorManger.primary,
            backgroundColor:
                messages.isNotEmpty ? Colors.white : Color(0xFFE3DCE4),
            elevation: 0,
            side:
                messages.isNotEmpty
                    ? const BorderSide(color: ColorManger.primary, width: 1)
                    : null,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          icon: Icon(
            Icons.picture_as_pdf_outlined,
            color: messages.isNotEmpty ? ColorManger.primary : Colors.grey,
          ),
          label: Text(
            AppStrings.exportPdf.tr(context),
            style: TextStyle(
              color: messages.isNotEmpty ? ColorManger.primary : Colors.grey,
            ),
          ),
          onPressed: () async {
            final messages = ref.read(parsedMessagesProvider);

            if (messages.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Center(
                    child: Text(AppStrings.noDataToExport.tr(context)),
                  ),
                  duration: const Duration(seconds: 1),
                  behavior: SnackBarBehavior.floating,
                ),
              );
              return;
            }
            final sorted = [...messages]..sort((a, b) {
              final dtA = DateTime(
                a.year,
                a.month,
                a.day,
                a.hour,
                a.minute,
                a.second,
              );
              final dtB = DateTime(
                b.year,
                b.month,
                b.day,
                b.hour,
                b.minute,
                b.second,
              );
              return dtA.compareTo(dtB);
            });

            final first = DateTime(
              sorted.first.year,
              sorted.first.month,
              sorted.first.day,
              sorted.first.hour,
              sorted.first.minute,
              sorted.first.second,
            );

            final last = DateTime(
              sorted.last.year,
              sorted.last.month,
              sorted.last.day,
              sorted.last.hour,
              sorted.last.minute,
              sorted.last.second,
            );

            final result = await showDialog<_DateRange?>(
              context: context,
              builder:
                  (_) => _DateRangeDialog(initialFrom: first, initialTo: last),
            );

            if (result == null) return;

            final filtered =
                messages.where((msg) {
                  final dt = DateTime(
                    msg.year,
                    msg.month,
                    msg.day,
                    msg.hour,
                    msg.minute,
                    msg.second,
                  );
                  return !dt.isBefore(result.from) &&
                      !dt.isAfter(result.to); // ✅
                }).toList();

            await _exportToPdf(context, filtered);
          },
        ),
      ),
    );
  }
}

class _DateRangeDialog extends StatefulWidget {
  final DateTime initialFrom;
  final DateTime initialTo;

  const _DateRangeDialog({required this.initialFrom, required this.initialTo});

  @override
  State<_DateRangeDialog> createState() => _DateRangeDialogState();
}

class _DateRangeDialogState extends State<_DateRangeDialog> {
  late DateTime from;
  late DateTime to;

  @override
  void initState() {
    super.initState();
    from = widget.initialFrom;
    to = widget.initialTo;
  }

  Future<void> pickDateTime({required bool isFrom}) async {
    final current = isFrom ? from : to;

    final date = await showDatePicker(
      context: context,
      initialDate: current,
      firstDate: widget.initialFrom,
      lastDate: widget.initialTo,
    );
    if (date == null) return;

    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(current),
    );
    if (time == null) return;

    final selected = DateTime(
      date.year,
      date.month,
      date.day,
      time.hour,
      time.minute,
    );
    setState(() {
      if (isFrom) {
        from = selected;
      } else {
        to = selected;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFFF3EEF9),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(
        AppStrings.selectDateRange.tr(context),
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: ColorManger.primary,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: const BorderSide(color: ColorManger.primary),
              ),
            ),
            icon: const Icon(Icons.calendar_today),
            label: Text(
              "${AppStrings.from.tr(context)}: ${DateFormat(AppStrings.dateTimeFormat.tr(context)).format(from)}",
            ),
            onPressed: () => pickDateTime(isFrom: true),
          ),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: ColorManger.primary,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: const BorderSide(color: ColorManger.primary),
              ),
            ),
            icon: const Icon(Icons.calendar_today_outlined),
            label: Text(
              "${AppStrings.to.tr(context)}: ${DateFormat(AppStrings.dateTimeFormat.tr(context)).format(to)}",
            ),
            onPressed: () => pickDateTime(isFrom: false),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            setState(() {
              from = widget.initialFrom;
              to = widget.initialTo;
            });
            // Navigator.pop(context);
          },
          child: Text(
            AppStrings.reset.tr(context),
            style: TextStyle(color: ColorManger.primary),
          ),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(
            AppStrings.cancel.tr(context),
            style: TextStyle(color: ColorManger.primary),
          ),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: ColorManger.primary,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
          ),
          onPressed:
              (from.isBefore(to) || from.isAtSameMomentAs(to))
                  ? () => Navigator.pop(context, _DateRange(from: from, to: to))
                  : null,
          child: Text(
            AppStrings.export.tr(context),
            style: TextStyle(color: Colors.white),
          ),
        ),
      ],
    );
  }
}

class _DateRange {
  final DateTime from;
  final DateTime to;

  _DateRange({required this.from, required this.to});
}

class _PdfData {
  final List<ParsedMessage> messages;
  final Uint8List imageBytes;

  _PdfData({required this.messages, required this.imageBytes});
}

Future<Uint8List> buildPdfInIsolate(_PdfData data) async {
  final pdf = pw.Document();

  final List<List<String>> groupedData = [];
  for (int i = 0; i < data.messages.length; i += 3) {
    final row = <String>[];
    for (int j = 0; j < 3; j++) {
      if (i + j < data.messages.length) {
        final msg = data.messages[i + j];
        final dateTime = DateTime(
          msg.year,
          msg.month,
          msg.day,
          msg.hour,
          msg.minute,
          msg.second,
        );
        row.add(
          DateFormat(AppStrings.dateTimeFormatWithSeconds).format(dateTime),
        );
        row.add(msg.temperature.toStringAsFixed(2));
        row.add(msg.humidity.toStringAsFixed(2));
      } else {
        row.add('');
        row.add('');
        row.add('');
      }
    }
    groupedData.add(row);
  }

  final headers = <String>[];
  for (int i = 0; i < 3; i++) {
    headers.add('Time');
    headers.add('Temp °C');
    headers.add('RH %');
  }

  pdf.addPage(
    pw.MultiPage(
      pageTheme: pw.PageTheme(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(20),
        buildBackground:
            (context) => pw.Center(
              child: pw.Opacity(
                opacity: 0.2,
                child: pw.Image(pw.MemoryImage(data.imageBytes)),
              ),
            ),
      ),

      build:
          (pw.Context context) => [
            pw.Text(
              AppStrings.dataLoggerReport,
              style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 20),
            pw.TableHelper.fromTextArray(
              headers: headers,
              data: groupedData,
              cellPadding: const pw.EdgeInsets.symmetric(
                vertical: 1,
                horizontal: 2,
              ),
              border: pw.TableBorder.all(color: PdfColors.grey500, width: 0.5),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
              cellStyle: pw.TextStyle(fontSize: 6.5),
              headerDecoration: const pw.BoxDecoration(
                color: PdfColors.grey300,
              ),
              cellAlignment: pw.Alignment.center,
            ),
          ],
    ),
  );

  return pdf.save();
}

Future<void> _exportToPdf(
  BuildContext context,
  List<ParsedMessage> messages,
) async {
  if (messages.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(AppStrings.noDataInRangeWarning.tr(context)),
        duration: const Duration(seconds: 1),
      ),
    );
    return;
  }

  showDialog(
    context: context,
    barrierDismissible: false,
    builder:
        (_) => const Center(
          child: SuccessLottie(message: '', path: 'assets/loading.json'),
        ),
  );

  try {
    // Load the asset image using rootBundle (works in both debug and release modes)
    final ByteData imageData = await rootBundle.load('assets/images/atmoslink_stacked.png');
    final Uint8List imageBytes = imageData.buffer.asUint8List();

    // Pass both messages and image bytes to the isolate
    final pdfData = _PdfData(messages: messages, imageBytes: imageBytes);
    final pdfBytes = await compute(buildPdfInIsolate, pdfData);

    final output = await getApplicationDocumentsDirectory();
    final file = File("${output.path}/data_logger_report.pdf");
    await file.writeAsBytes(pdfBytes);

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfBytes,
    );
    Navigator.of(context).pop();
    // ScaffoldMessenger.of(context).showSnackBar(
    //   SnackBar(
    //     content: Center(
    //       child: Text(AppStrings.theReportWasSavedSuccessfully.tr(context)),
    //     ),
    //     duration: const Duration(seconds: 1),
    //   ),
    // );
  } catch (e) {
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(AppStrings.anErrorOssurredWhileSaving.tr(context)),
        duration: const Duration(seconds: 1),
      ),
    );
  }
}
