import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/model/model.dart';
import 'package:data_logger/view_model/filter_range_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class FilterButton extends ConsumerWidget {
  final List<ParsedMessage> messages;

  const FilterButton({super.key, required this.messages});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      height: 55.h,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          foregroundColor: ColorManger.primary,
          backgroundColor: Colors.white,
          elevation: 0,
          side: const BorderSide(color: ColorManger.primary, width: 1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: () => _showFilterDialog(context, ref),
        icon: const Icon(Icons.filter_alt_outlined, color: ColorManger.primary),
        label: Text(
          AppStrings.filterData.tr(context),
          style: const TextStyle(color: ColorManger.primary),
        ),
      ),
    );
  }

  Future<void> _showFilterDialog(BuildContext context, WidgetRef ref) async {
    if (messages.isEmpty) return;

    final sorted = [...messages]..sort((a, b) {
      final dtA = DateTime(a.year, a.month, a.day, a.hour, a.minute, a.second);
      final dtB = DateTime(b.year, b.month, b.day, b.hour, b.minute, b.second);
      return dtA.compareTo(dtB);
    });

    DateTime from = DateTime(
      sorted.first.year,
      sorted.first.month,
      sorted.first.day,
      sorted.first.hour,
      sorted.first.minute,
      sorted.first.second,
    );
    DateTime to = DateTime(
      sorted.last.year,
      sorted.last.month,
      sorted.last.day,
      sorted.last.hour,
      sorted.last.minute,
      sorted.last.second,
    );

    Future<DateTime?> pick(String label, DateTime initial) async {
      final d = await showDatePicker(
        context: context,
        initialDate: initial,
        firstDate: sorted.firstDateTime,
        lastDate: sorted.lastDateTime,
      );
      if (d == null) return null;
      final t = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(initial),
      );
      if (t == null) return null;
      return DateTime(
        d.year,
        d.month,
        d.day,
        t.hour,
        t.minute,
        initial.second,
      ); // احتفظ بالثواني الأصلية
    }

    await showDialog(
      context: context,
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              backgroundColor: const Color(0xFFF3EEF9),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              title: Text(
                AppStrings.filterByDateRange.tr(context),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.calendar_today),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: ColorManger.primary,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: const BorderSide(color: ColorManger.primary),
                      ),
                    ),
                    onPressed: () async {
                      final res = await pick(AppStrings.from.tr(context), from);
                      if (res != null) setStateDialog(() => from = res);
                    },
                    label: Text(
                      '${AppStrings.from.tr(context)}: ${from.toString().substring(0, 16)}',
                    ),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.calendar_today),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: ColorManger.primary,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: const BorderSide(color: ColorManger.primary),
                      ),
                    ),
                    onPressed: () async {
                      final res = await pick(AppStrings.to.tr(context), to);
                      if (res != null) setStateDialog(() => to = res);
                    },
                    label: Text(
                      '${AppStrings.to.tr(context)}: ${to.toString().substring(0, 16)}',
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    ref.read(filterRangeProvider.notifier).state = null;
                    Navigator.pop(context);
                  },
                  child: Text(
                    AppStrings.reset.tr(context),
                    style: const TextStyle(color: ColorManger.primary),
                  ),
                ),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    AppStrings.cancel.tr(context),
                    style: const TextStyle(color: ColorManger.primary),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ColorManger.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed:
                      (from.isBefore(to) || from.isAtSameMomentAs(to))
                          ? () {
                            ref
                                .read(filterRangeProvider.notifier)
                                .state = DateTimeRange(start: from, end: to);
                            Navigator.pop(context);
                          }
                          : null,
                  child: Text(
                    AppStrings.apply.tr(context),
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

extension DateHelpers on List<ParsedMessage> {
  DateTime get firstDateTime => DateTime(
    first.year,
    first.month,
    first.day,
    first.hour,
    first.minute,
    first.second,
  );

  DateTime get lastDateTime => DateTime(
    last.year,
    last.month,
    last.day,
    last.hour,
    last.minute,
    last.second,
  );
}
