import 'package:data_logger/core/corlor_manger.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

// ignore: must_be_immutable
class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool enabled;
  Icon? icon;
  CustomButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.enabled = true,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 55.h,
      child: ElevatedButton.icon(
        icon: icon,
        onPressed: enabled ? onPressed : null,
        style: ElevatedButton.styleFrom(
          minimumSize: const Size(150, 50),
          foregroundColor: ColorManger.primary,
          backgroundColor: Colors.white,
          elevation: 0,
          side: enabled ? const BorderSide(color: ColorManger.primary, width: 1) : null,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        label: Text(
          text,
          style: TextStyle(color: enabled ? ColorManger.primary : Colors.grey),
        ),
      ),
    );
  }
}
