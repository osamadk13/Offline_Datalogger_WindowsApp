import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class NoDataAnalysisScreen extends StatelessWidget {
  const NoDataAnalysisScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(32.0.r),
      child: Column(
        children: [
          SizedBox(height: 40),
          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(width: 300.w, child: _buildContactInfo(context)),
                SizedBox(width: 160.w),
                SizedBox(width: 600.w, child: _buildImageOrMapPlaceholder()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactInfo(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.noDataForAnalysis.tr(context),
          style: TextStyle(fontSize: 25.sp, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 24.h),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              Icons.analytics_outlined,
              size: 24.sp,
              color: ColorManger.accent,
            ),
            SizedBox(width: 16.w),

            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  AppStrings.pleaseConnectToDatalogger.tr(context),
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildImageOrMapPlaceholder() {
    return Column(
      children: [
        Image.asset("assets/images/analysis1.png", fit: BoxFit.contain),
        SizedBox(height: 40),
        Image.asset('assets/images/analysis2.png', fit: BoxFit.contain),
      ],
    );
  }
}
