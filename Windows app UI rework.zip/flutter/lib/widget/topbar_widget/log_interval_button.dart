import 'package:data_logger/core/corlor_manger.dart';
import 'dart:typed_data';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/core/data_logger_frame.dart'; // نحتاج هذه الدالة
import 'package:data_logger/view_model/log_interval_provider.dart';
import 'package:data_logger/view_model/serial_port_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class LogIntervalButton extends ConsumerWidget {
  const LogIntervalButton({super.key});

  // دالة إرسال فترة التسجيل إلى الجهاز
  void _sendLogInterval(WidgetRef ref, int logInterval) {
    try {
      final frame = buildLogIntervalFrame(logInterval);
      ref
          .read(serialPortServiceProvider.notifier)
          .writeData(Uint8List.fromList(frame));
      debugPrint('✅ Frame sent: $frame');
    } catch (e) {
      debugPrint('❌ Failed to send logInterval frame: $e');
    }
  }

  // دالة عرض مربع حوار الإدخال
  Future<void> _showIntervalDialog(BuildContext context, WidgetRef ref) async {
    final logInterval = await showDialog<int>(
      context: context,
      builder: (context) {
        final controller = TextEditingController();
        return AlertDialog(
          title: Text(
            AppStrings.enterLogInterval.tr(context),
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.white,
              enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: ColorManger.primary, width: 1.5),
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: ColorManger.primary, width: 2),
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              hintText: AppStrings.enterValidNumber1To255.tr(context),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                AppStrings.cancel.tr(context),
                style: const TextStyle(color: ColorManger.primary),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: ColorManger.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              onPressed: () {
                final input = int.tryParse(controller.text);
                if (input != null && input >= 1 && input <= 255) {
                  Navigator.of(context).pop(input);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Center(
                        child: Text(
                          AppStrings.enterValidNumber1To255.tr(context),
                        ),
                      ),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                }
              },
              child: Text(
                AppStrings.ok.tr(context),
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ],
        );
      },
    );

    if (logInterval != null) {
      // حفظ وإرسال فترة التسجيل
      ref.read(logIntervalProvider.notifier).state = logInterval;
      _sendLogInterval(ref, logInterval);

      // عرض رسالة توضيحية للمستخدم
      if (context.mounted) {
        showDialog(
          context: context,
          barrierDismissible: true,
          builder:
              (context) => AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                title: Row(
                  children: [
                    const Icon(
                      Icons.check_circle,
                      color: Colors.green,
                      size: 28,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      AppStrings.success.tr(context),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      AppStrings.settingsSavedSuccessfully.tr(context),
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: ColorManger.primaryLight,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: ColorManger.primary),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.info_outline,
                            color: ColorManger.primary,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              AppStrings.newIntervalWillShowAfterTwoReadings.tr(
                                context,
                              ),
                              style: TextStyle(
                                fontSize: 14,
                                color: ColorManger.primary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    style: TextButton.styleFrom(
                      backgroundColor: ColorManger.primary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Text(
                      AppStrings.ok.tr(context),
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isConnected = ref.watch(serialPortServiceProvider).isConnected;

    return SizedBox(
      height: 55.h,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          foregroundColor: ColorManger.primary,
          backgroundColor: Colors.white,
          elevation: 0,
          side:
              isConnected
                  ? const BorderSide(color: ColorManger.primary, width: 1)
                  : null,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: isConnected ? () => _showIntervalDialog(context, ref) : null,
        icon: Icon(
          Icons.timer_sharp,
          color: isConnected ? ColorManger.primary : Colors.grey,
        ),
        label: Text(
          AppStrings.timeInterval.tr(context),
          style: TextStyle(color: isConnected ? ColorManger.primary : Colors.grey),
        ),
      ),
    );
  }
}
