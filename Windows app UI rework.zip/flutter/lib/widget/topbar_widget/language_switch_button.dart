import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/view_model/language_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class LanguageSwitchButton extends ConsumerWidget {
  const LanguageSwitchButton({super.key});

  // هذه هي الدالة التي كانت موجودة داخل onPressed سابقاً
  void _showLanguageDialog(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(AppStrings.changeLanguage.tr(context)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: Text(AppStrings.english.tr(context)),
                onTap: () {
                  Navigator.of(context).pop();
                  ref.read(languageProvider.notifier).setEnglish();
                },
              ),
              ListTile(
                title: Text(AppStrings.arabic.tr(context)),
                onTap: () {
                  Navigator.of(context).pop();
                  ref.read(languageProvider.notifier).setArabic();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      height: 55.h,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          foregroundColor: ColorManger.primary,
          backgroundColor: Colors.white,
          elevation: 0,
          side: const BorderSide(color: ColorManger.primary, width: 1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: () => _showLanguageDialog(context, ref),
        icon: const Icon(Icons.language, color: ColorManger.primary),
        label: Text(
          AppStrings.changeLanguage.tr(context),
          style: const TextStyle(color: ColorManger.primary),
        ),
      ),
    );
  }
}
