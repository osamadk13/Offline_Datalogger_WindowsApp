import 'package:data_logger/core/corlor_manger.dart';
import 'dart:typed_data';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/core/data_logger_frame.dart'; // نحتاج هذه الدالة
import 'package:data_logger/view_model/serial_port_service.dart';
import 'package:data_logger/widget/success_lottie.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SyncTimeButton extends ConsumerWidget {
  const SyncTimeButton({super.key});

  // تم دمج الدوال المساعدة (setting و settingTime) هنا لتبسيط الاستدعاء
  Future<void> _settingTime(BuildContext context, WidgetRef ref) async {
    final serialPortNotifier = ref.read(serialPortServiceProvider.notifier);
    final isConnected = ref.read(serialPortServiceProvider).isConnected;

    if (!isConnected) {
      debugPrint("❌ Not connected to port");
      // عرض رسالة الخطأ
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Center(
            child: Text(AppStrings.deviceNotConnected.tr(context)),
          ),
          duration: const Duration(seconds: 1),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    // عرض شاشة الـ Lottie
    showDialog(
      context: context,
      barrierDismissible: false,
      builder:
          (_) => const AlertDialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            content: SuccessLottie(message: '', path: 'assets/done.json'),
          ),
    );

    try {
      final now = DateTime.now();
      // يتم افتراض وجود buildTimeFrame و buildDateFrame في data_logger_frame.dart
      final timeFrame = buildTimeFrame(now.hour, now.minute, now.second);
      final dateFrame = buildDateFrame(
        now.year,
        now.month,
        now.day,
        now.weekday,
      );

      await Future.delayed(const Duration(milliseconds: 200));
      serialPortNotifier.writeData(Uint8List.fromList(timeFrame));
      debugPrint("✅ Time frame sent: $timeFrame");

      await Future.delayed(const Duration(milliseconds: 300));
      serialPortNotifier.writeData(Uint8List.fromList(dateFrame));
      debugPrint("✅ Date frame sent: $dateFrame");
    } catch (e) {
      debugPrint("❌ Failed to send setting frames: $e");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("${AppStrings.failed.tr(context)}: $e"),
            duration: const Duration(seconds: 1),
          ),
        );
      }
    } finally {
      // إغلاق شاشة الـ Lottie
      Future.delayed(const Duration(seconds: 2), () {
        if (context.mounted) Navigator.of(context).pop();
      });
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isConnected = ref.watch(serialPortServiceProvider).isConnected;

    return SizedBox(
      height: 55.h,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          foregroundColor: ColorManger.primary,
          backgroundColor: Colors.white,
          elevation: 0,
          side:
              isConnected
                  ? const BorderSide(color: ColorManger.primary, width: 1)
                  : null,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: isConnected ? () => _settingTime(context, ref) : null,
        icon: Icon(Icons.sync, color: isConnected ? ColorManger.primary : Colors.grey),
        label: Text(
          AppStrings.syncTimeAndDate.tr(context),
          style: TextStyle(color: isConnected ? ColorManger.primary : Colors.grey),
        ),
      ),
    );
  }
}
