import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/view_model/serial_port_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ConnectDisconnectButton extends ConsumerWidget {
  const ConnectDisconnectButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // قراءة حالة الاتصال من Provider
    final isConnected = ref.watch(serialPortServiceProvider).isConnected;

    // استخدام ref.read لقراءة المُنبه (Notifier) لإجراء الأوامر
    final serialPortNotifier = ref.read(serialPortServiceProvider.notifier);

    return SizedBox(
      height: 55.h,
      child: ElevatedButton.icon(
        onPressed: () async {
          if (isConnected) {
            serialPortNotifier.disconnect();
          } else {
            await serialPortNotifier.connectToPort(context);
          }
        },
        style: ElevatedButton.styleFrom(
          foregroundColor: isConnected ? Colors.red : ColorManger.primary,
          backgroundColor: Colors.white,
          elevation: 0,
          side: BorderSide(
            color: isConnected ? Colors.red : ColorManger.primary,
            width: 1,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        icon: Icon(
          isConnected ? Icons.link_off : Icons.link,
          color: isConnected ? Colors.red : ColorManger.primary,
        ),
        label: Text(
          isConnected
              ? AppStrings.disconnect.tr(context)
              : AppStrings.connect.tr(context),
        ),
      ),
    );
  }
}
