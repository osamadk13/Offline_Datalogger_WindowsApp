import 'package:data_logger/core/corlor_manger.dart';
import 'dart:typed_data';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/core/data_logger_frame.dart'; // نحتاج هذه الدالة
import 'package:data_logger/view_model/serial_port_service.dart';
import 'package:data_logger/widget/success_lottie.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ManualTimeButton extends ConsumerWidget {
  const ManualTimeButton({super.key});

  // دالة إرسال الوقت والتاريخ اليدوي إلى الجهاز
  Future<void> _settingTimeManual(
    BuildContext context,
    WidgetRef ref,
    DateTime selectedDateTime,
  ) async {
    final serialPortNotifier = ref.read(serialPortServiceProvider.notifier);
    final isConnected = ref.read(serialPortServiceProvider).isConnected;

    if (!isConnected) {
      debugPrint("❌ Not connected to port");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Center(
              child: Text(AppStrings.deviceNotConnected.tr(context)),
            ),
            duration: const Duration(seconds: 1),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
      return;
    }

    if (context.mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder:
            (_) => const AlertDialog(
              backgroundColor: Colors.transparent,
              elevation: 0,
              content: SuccessLottie(message: '', path: 'assets/done.json'),
            ),
      );
    }

    try {
      final timeFrame = buildTimeFrame(
        selectedDateTime.hour,
        selectedDateTime.minute,
        selectedDateTime.second,
      );

      final dateFrame = buildDateFrame(
        selectedDateTime.year,
        selectedDateTime.month,
        selectedDateTime.day,
        selectedDateTime.weekday,
      );

      await Future.delayed(const Duration(milliseconds: 200));
      serialPortNotifier.writeData(Uint8List.fromList(timeFrame));
      debugPrint("✅ Time frame sent: $timeFrame");

      await Future.delayed(const Duration(milliseconds: 300));
      serialPortNotifier.writeData(Uint8List.fromList(dateFrame));
      debugPrint("✅ Date frame sent: $dateFrame");
    } catch (e) {
      debugPrint("❌ Failed to send setting frames: $e");
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("${AppStrings.failed.tr(context)}: $e"),
            duration: const Duration(seconds: 1),
          ),
        );
      }
    } finally {
      Future.delayed(const Duration(seconds: 2), () {
        if (context.mounted) Navigator.of(context).pop();
      });
    }
  }

  // دالة اختيار التاريخ والوقت
  Future<void> _pickDateTimeAndSet(BuildContext context, WidgetRef ref) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );

    if (pickedDate == null) return;

    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (pickedTime == null) return;

    final DateTime selectedDateTime = DateTime(
      pickedDate.year,
      pickedDate.month,
      pickedDate.day,
      pickedTime.hour,
      pickedTime.minute,
      0,
      0,
      0,
    );

    await _settingTimeManual(context, ref, selectedDateTime);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isConnected = ref.watch(serialPortServiceProvider).isConnected;

    return SizedBox(
      height: 55.h,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          foregroundColor: ColorManger.primary,
          backgroundColor: Colors.white,
          elevation: 0,
          side:
              isConnected
                  ? const BorderSide(color: ColorManger.primary, width: 1)
                  : null,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: isConnected ? () => _pickDateTimeAndSet(context, ref) : null,
        icon: Icon(Icons.timer, color: isConnected ? ColorManger.primary : Colors.grey),
        label: Text(
          AppStrings.timeAndDateManual.tr(context),
          style: TextStyle(color: isConnected ? ColorManger.primary : Colors.grey),
        ),
      ),
    );
  }
}
