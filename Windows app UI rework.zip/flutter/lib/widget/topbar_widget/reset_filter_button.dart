import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/view_model/filter_range_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ResetFilterButton extends ConsumerWidget {
  const ResetFilterButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      height: 55.h,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          foregroundColor: ColorManger.primary,
          backgroundColor: Colors.white,
          elevation: 0,
          side: const BorderSide(color: ColorManger.primary, width: 1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: () {
          // إعادة تعيين الفلترة بجعل قيمة الـ State هي null
          ref.read(filterRangeProvider.notifier).state = null;
        },
        icon: const Icon(Icons.refresh, color: ColorManger.primary),
        label: Text(
          AppStrings.reset.tr(context),
          style: const TextStyle(color: ColorManger.primary),
        ),
      ),
    );
  }
}
