import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/view_model/serial_port_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ReadDataButton extends ConsumerWidget {
  const ReadDataButton({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // قراءة حالة الاتصال من Provider
    final isConnected = ref.watch(serialPortServiceProvider).isConnected;

    return SizedBox(
      height: 55.h,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          foregroundColor: ColorManger.primary,
          backgroundColor: Colors.white,
          elevation: 0,
          side:
              isConnected
                  ? const BorderSide(color: ColorManger.primary, width: 1)
                  : null,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        // تفعيل الزر فقط عند الاتصال
        onPressed:
            isConnected
                ? () {
                  ref
                      .read(serialPortServiceProvider.notifier)
                      .sendCommand(context);
                }
                : null,
        icon: Icon(
          Icons.download,
          color: isConnected ? ColorManger.primary : Colors.grey,
        ),
        label: Text(
          AppStrings.readData.tr(context),
          style: TextStyle(color: isConnected ? ColorManger.primary : Colors.grey),
        ),
      ),
    );
  }
}
