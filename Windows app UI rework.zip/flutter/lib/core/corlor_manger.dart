import 'package:flutter/material.dart';

class ColorManger {
  // AtmosLink brand
  static const Color primary = Color(0xff123E70); // navy
  static const Color primaryLight = Color(0xffEAF0F7); // selected tint
  static const Color accent = Color(0xff2E9CC2); // teal
  static const Color secondary = Color(0xff000000);
}
