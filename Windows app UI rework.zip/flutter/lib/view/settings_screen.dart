import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settingsOptions = [
      {
        'icon': Icons.refresh,
        'title': AppStrings.refreshAndConnect.tr(context),
        'subtitle': AppStrings.refreshAndConnectDescription.tr(context),
      },
      {
        'icon': Icons.timer,
        'title': AppStrings.setTimeInterval.tr(context),
        'subtitle': AppStrings.setTimeIntervalDescription.tr(context),
      },
      {
        'icon': Icons.access_time,
        'title': AppStrings.setDateTime.tr(context),
        'subtitle': AppStrings.setDateTimeDescription.tr(context),
      },
      {
        'icon': Icons.delete_forever,
        'title': AppStrings.clearDeviceData.tr(context),
        'subtitle': AppStrings.clearDeviceDataDescription.tr(context),
      },
      {
        'icon': Icons.download,
        'title': AppStrings.downloadConnectionDefinitions.tr(context),
        'subtitle': AppStrings.toConnectTheDeviceProperly.tr(context),
        'isDriver': true,
      },
    ];
    final theme = Theme.of(context);
    return Center(
      child: Container(
        constraints: BoxConstraints(maxWidth: 800.w),
        padding: const EdgeInsets.only(top: 120, bottom: 100),
        child: ListView.builder(
          itemCount: settingsOptions.length,
          itemBuilder: (context, index) {
            final setting = settingsOptions[index];
            return Container(
              margin: const EdgeInsets.symmetric(vertical: 10),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    // ignore: deprecated_member_use
                    backgroundColor: theme.primaryColor.withOpacity(0.1),
                    child: Icon(
                      setting['icon'] as IconData,
                      color: ColorManger.primary,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          setting['title'] as String,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          setting['subtitle'] as String,
                          style: theme.textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
