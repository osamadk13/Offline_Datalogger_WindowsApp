import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/view_model/data_analysis_provider.dart';
import 'package:data_logger/view_model/datalogger_provider.dart';
import 'package:data_logger/view_model/language_provider.dart';
import 'package:data_logger/view_model/serial_port_service.dart';
// import 'package:data_logger/view_model/serial_setting_privider.dart';
import 'package:data_logger/widget/chart_type.dart';
import 'package:data_logger/widget/custom_button.dart';
import 'package:data_logger/widget/export_chart_to_pdf.dart';
import 'package:data_logger/widget/no_data_analysis_screen.dart';
import 'package:data_logger/widget/success_lottie.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class DataAnalysisScreen extends ConsumerWidget {
  const DataAnalysisScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final messages = ref.watch(parsedMessagesProvider);
    final chartType = ref.watch(chartTypeProvider);
    final GlobalKey chartKey = GlobalKey();

    final startDay = ref.watch(selectedStartDayProvider);
    final endDay = ref.watch(selectedEndDayProvider);
    final showList = ref.watch(showListProvider);

    final filteredMessages =
        (startDay == null || endDay == null)
            ? messages
            : messages.where((msg) {
              final msgDate = DateTime(
                msg.year,
                msg.month,
                msg.day,
                msg.hour,
                msg.minute,
                msg.second,
              );
              final adjustedEnd = endDay.add(const Duration(seconds: 59));

              return !msgDate.isBefore(startDay) &&
                  !msgDate.isAfter(adjustedEnd);
            }).toList();
    final locale = ref.watch(languageProvider).locale.languageCode;

    final isArabic = locale == 'ar';
    // if (messages.isEmpty) {
    //   return NoDataAnalysisScreen();
    // }

    return Column(
      children: [
        Flexible(
          flex: 1,
          child: Padding(
            padding: EdgeInsets.all(20.0.r),
            child: Column(
              children: [
                Row(
                  children: [
                    ////////////    chooseDayToAnalyze       ////////////
                    CustomButton(
                      icon: Icon(
                        Icons.date_range,
                        color:
                            ref.watch(serialPortServiceProvider).isConnected
                                ? ColorManger.primary
                                : Colors.grey,
                      ),
                      text: AppStrings.chooseDayToAnalyze.tr(context),

                      enabled:
                          ref.watch(serialPortServiceProvider).isConnected
                              ? true
                              : false,
                      onPressed: () async {
                        DateTime? startDate = ref.read(
                          selectedStartDayProvider,
                        );
                        DateTime? endDate = ref.read(selectedEndDayProvider);

                        // final now = DateTime.now();
                        // startDate ??= DateTime(now.year, now.month, now.day, 0, 0);
                        // endDate ??= now;
                        // اجلب كل الرسائل الموجودة
                        // final messages = ref.read(parsedMessagesProvider);

                        // لو في داتا، استخدم أول وآخر قراءة كتاريخ مبدئي
                        if (messages.isNotEmpty) {
                          // تأكد الأول إنهم مترتبين زمنياً
                          messages.sort((a, b) {
                            final dateA = DateTime(
                              a.year,
                              a.month,
                              a.day,
                              a.hour,
                              a.minute,
                              a.second,
                            );
                            final dateB = DateTime(
                              b.year,
                              b.month,
                              b.day,
                              b.hour,
                              b.minute,
                              b.second,
                            );
                            return dateA.compareTo(dateB);
                          });

                          final firstMsg = messages.first;
                          final lastMsg = messages.last;

                          startDate ??= DateTime(
                            firstMsg.year,
                            firstMsg.month,
                            firstMsg.day,
                            firstMsg.hour,
                            firstMsg.minute,
                          );
                          endDate ??= DateTime(
                            lastMsg.year,
                            lastMsg.month,
                            lastMsg.day,
                            lastMsg.hour,
                            lastMsg.minute,
                          );
                        } else {
                          // fallback لو مفيش داتا
                          final now = DateTime.now();
                          startDate ??= DateTime(
                            now.year,
                            now.month,
                            now.day,
                            0,
                            0,
                          );
                          endDate ??= now;
                        }

                        Future<DateTime?> pickDateTime(
                          String label,
                          DateTime initial,
                        ) async {
                          final pickedDate = await showDatePicker(
                            context: context,
                            initialDate: initial,
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now(),
                          );
                          if (pickedDate == null) return null;

                          final pickedTime = await showTimePicker(
                            context: context,
                            initialTime: TimeOfDay.fromDateTime(initial),
                          );
                          if (pickedTime == null) return null;

                          return DateTime(
                            pickedDate.year,
                            pickedDate.month,
                            pickedDate.day,
                            pickedTime.hour,
                            pickedTime.minute,
                          );
                        }

                        await showDialog(
                          context: context,
                          builder: (_) {
                            return StatefulBuilder(
                              builder: (context, setStateDialog) {
                                return AlertDialog(
                                  backgroundColor: const Color(0xFFF3EEF9),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  title: Text(
                                    AppStrings.chooseDayToAnalyze.tr(context),
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  content: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SizedBox(
                                        height: 55.h,
                                        child: ElevatedButton.icon(
                                          icon: const Icon(
                                            Icons.calendar_today,
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.white,
                                            foregroundColor: ColorManger.primary,
                                            elevation: 0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              side: const BorderSide(
                                                color: ColorManger.primary,
                                              ),
                                            ),
                                          ),
                                          onPressed: () async {
                                            final res = await pickDateTime(
                                              AppStrings.startDate.tr(context),
                                              startDate!,
                                            );
                                            if (res != null) {
                                              setStateDialog(
                                                () => startDate = res,
                                              );
                                            }
                                          },
                                          label: Text(
                                            "${AppStrings.from.tr(context)}: ${DateFormat('yyyy-MM-dd HH:mm').format(startDate!)}",
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 12),
                                      SizedBox(
                                        height: 55.h,
                                        child: ElevatedButton.icon(
                                          icon: const Icon(
                                            Icons.calendar_today,
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.white,
                                            foregroundColor: ColorManger.primary,
                                            elevation: 0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              side: const BorderSide(
                                                color: ColorManger.primary,
                                              ),
                                            ),
                                          ),
                                          onPressed: () async {
                                            final res = await pickDateTime(
                                              AppStrings.endDate.tr(context),
                                              endDate!,
                                            );
                                            if (res != null) {
                                              setStateDialog(
                                                () => endDate = res,
                                              );
                                            }
                                          },
                                          label: Text(
                                            "${AppStrings.to.tr(context)}: ${DateFormat('yyyy-MM-dd HH:mm').format(endDate!)}",
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () {
                                        ref
                                            .read(
                                              selectedStartDayProvider.notifier,
                                            )
                                            .state = null;
                                        ref
                                            .read(
                                              selectedEndDayProvider.notifier,
                                            )
                                            .state = null;
                                        Navigator.pop(context);
                                      },
                                      child: Text(
                                        AppStrings.reset.tr(context),
                                        style: TextStyle(color: ColorManger.primary),
                                      ),
                                    ),
                                    TextButton(
                                      onPressed: () => Navigator.pop(context),
                                      child: Text(
                                        AppStrings.cancel.tr(context),
                                        style: TextStyle(color: ColorManger.primary),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 55.h,
                                      child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: ColorManger.primary,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              20,
                                            ),
                                          ),
                                        ),
                                        onPressed: () {
                                          ref
                                              .read(
                                                selectedStartDayProvider
                                                    .notifier,
                                              )
                                              .state = startDate;
                                          ref
                                              .read(
                                                selectedEndDayProvider.notifier,
                                              )
                                              .state = endDate;
                                          Navigator.pop(context);
                                        },
                                        child: Text(
                                          AppStrings.apply.tr(context),
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              },
                            );
                          },
                        );
                      },
                    ),
                    /////////////  reset  ////////////
                    SizedBox(width: 20.w),
                    (startDay != null && endDay != null)
                        ? CustomButton(
                          icon: const Icon(Icons.refresh, color: ColorManger.primary),
                          text: AppStrings.reset.tr(context),
                          enabled: true,
                          onPressed: () {
                            ref.read(selectedStartDayProvider.notifier).state =
                                null;
                            ref.read(selectedEndDayProvider.notifier).state =
                                null;
                          },
                        )
                        : SizedBox.shrink(),

                    Spacer(),

                    CustomButton(
                      icon: Icon(
                        Icons.analytics,
                        color:
                            ref.watch(serialPortServiceProvider).isConnected
                                ? ColorManger.primary
                                : Colors.grey,
                      ),
                      text: AppStrings.changeChartType.tr(context),
                      enabled:
                          ref.watch(serialPortServiceProvider).isConnected
                              ? true
                              : false,
                      onPressed: () {
                        final current = ref.read(chartTypeProvider);
                        final next =
                            ChartType.values[(current.index + 1) %
                                ChartType.values.length];
                        ref.read(chartTypeProvider.notifier).state = next;
                      },
                    ),
                    SizedBox(width: 20.w),
                    CustomButton(
                      icon: Icon(
                        Icons.download,
                        color:
                            ref.watch(serialPortServiceProvider).isConnected
                                ? ColorManger.primary
                                : Colors.grey,
                      ),
                      text: AppStrings.exportChartToPdf.tr(context),
                      enabled:
                          ref.watch(serialPortServiceProvider).isConnected
                              ? true
                              : false,
                      onPressed: () => handleExport(context, chartKey, ref),
                    ),
                  ],
                ),
                SizedBox(height: 20.h),
                if (startDay != null && endDay != null)
                  Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: 16.w,
                      vertical: 8.h,
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.filter_alt_outlined,
                          color: Colors.black54,
                          size: 22.sp,
                        ),
                        SizedBox(width: 8.w),
                        Expanded(
                          child: Text(
                            isArabic
                                ? 'تم الفلترة من الساعة ${DateFormat('HH:mm', locale).format(startDay)} بتاريخ ${DateFormat('yyyy-MM-dd', locale).format(startDay)} '
                                    'إلى الساعة ${DateFormat('HH:mm', locale).format(endDay)} بتاريخ ${DateFormat('yyyy-MM-dd', locale).format(endDay)}'
                                : 'Filtered from ${DateFormat('HH:mm', locale).format(startDay)} on ${DateFormat('yyyy-MM-dd', locale).format(startDay)} '
                                    'to ${DateFormat('HH:mm', locale).format(endDay)} on ${DateFormat('yyyy-MM-dd', locale).format(endDay)}',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                              height: 1.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),

        Flexible(
          flex: 5,
          child:
              messages.isEmpty
                  ? NoDataAnalysisScreen()
                  : Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        Expanded(
                          child: AnimatedCrossFade(
                            duration: const Duration(milliseconds: 400),
                            crossFadeState:
                                showList
                                    ? CrossFadeState.showSecond
                                    : CrossFadeState.showFirst,
                            firstChild: RepaintBoundary(
                              key: chartKey,
                              child: SfCartesianChart(
                                legend: Legend(
                                  isVisible: true,
                                  toggleSeriesVisibility:
                                      true, // <== دي اللي بتخليك تتحكم في إظهار/إخفاء كل series
                                  position: LegendPosition.bottom,
                                ),
                                zoomPanBehavior: ZoomPanBehavior(
                                  enableMouseWheelZooming: true,
                                  enablePanning: true,
                                  zoomMode: ZoomMode.xy,
                                ),
                                primaryXAxis: CategoryAxis(
                                  // majorGridLines: const MajorGridLines(width: 1),
                                ),
                                series: buildChartSeries(
                                  chartType,
                                  filteredMessages,
                                  context,
                                ),
                              ),
                            ),
                            secondChild: SizedBox(
                              height: 700.h,
                              child: ListView.separated(
                                itemCount: filteredMessages.length,
                                separatorBuilder:
                                    (_, __) => const Divider(height: 1),
                                itemBuilder: (context, index) {
                                  final msg = filteredMessages[index];
                                  return ListTile(
                                    leading: const Icon(Icons.access_time),
                                    title: Text(
                                      "${msg.hour.toString().padLeft(2, '0')}:${msg.minute.toString().padLeft(2, '0')} - "
                                      "${msg.day}/${msg.month}/${msg.year}",
                                    ),
                                    subtitle: Text(
                                      "🌡 ${AppStrings.temperature.tr(context)}: ${msg.temperature} °C   "
                                      "💧 ${AppStrings.humidity.tr(context)}: ${msg.humidity} %",
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        ),

                        GestureDetector(
                          onTap: () {
                            ref.read(showListProvider.notifier).state =
                                !showList;
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: ColorManger.accent),
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(50),
                            ),
                            height: 80.h,
                            width: 80.w,
                            alignment: Alignment.center,
                            child: Icon(
                              showList
                                  ? Icons.keyboard_arrow_up
                                  : Icons.keyboard_arrow_down,
                              size: 30,
                              color: ColorManger.accent,
                            ),
                          ),
                        ),
                        SizedBox(height: 15.h),
                      ],
                    ),
                  ),
        ),
      ],
    );
  }
}

Future<void> handleExport(
  BuildContext context,
  GlobalKey chartKey,
  WidgetRef ref,
) async {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder:
        (_) => AlertDialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          content: SuccessLottie(message: '', path: 'assets/loading.json'),
        ),
  );

  await exportChartToPdf(chartKey, ref);
  Navigator.of(context).pop();
}
