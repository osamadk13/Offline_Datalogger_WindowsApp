import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:data_logger/view_model/datalogger_provider.dart';
import 'package:data_logger/view_model/filter_range_provider.dart';
import 'package:data_logger/view_model/language_provider.dart';
import 'package:data_logger/view_model/serial_port_service.dart';
// import 'package:data_logger/view_model/serial_setting_privider.dart';
import 'package:data_logger/widget/how_to_use.dart';
import 'package:data_logger/widget/success_lottie.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';

class DataTableViewScreen extends ConsumerWidget {
  const DataTableViewScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final messages = ref.watch(parsedMessagesProvider);
    final isLoading = ref.watch(serialPortServiceProvider).isLoading;
    final filterRange = ref.watch(filterRangeProvider);
    final isConnected = ref.watch(serialPortServiceProvider).isConnected;
    final locale = ref.watch(languageProvider).locale;

    final dataToShow =
        filterRange == null
            ? messages
            : messages.where((msg) {
              final dt = DateTime(
                msg.year,
                msg.month,
                msg.day,
                msg.hour,
                msg.minute,
                msg.second,
              );
              return !dt.isBefore(filterRange.start) &&
                  !dt.isAfter(filterRange.end);
            }).toList();

    return !isConnected
        ? HowToUse()
        : isLoading
        ? const Center(
          child: SuccessLottie(message: '', path: 'assets/loading.json'),
        )
        : dataToShow.isEmpty
        ? Center(
          child: Column(
            children: [
              Lottie.asset('assets/no_data.json', width: 300.sp),
              Text(
                AppStrings.noData.tr(context),
                style: TextStyle(fontSize: 20.sp),
              ),
            ],
          ),
        )
        : Card(
          color: Colors.white,
          child: Padding(
            padding: EdgeInsets.all(16.0.r),
            child: Column(
              children: [
                SizedBox(height: 10.h),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        textAlign: TextAlign.center,
                        AppStrings.time.tr(context),

                        style: TextStyle(
                          color: ColorManger.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        textAlign: TextAlign.center,
                        "${AppStrings.temperature.tr(context)} °C",
                        style: TextStyle(
                          color: ColorManger.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Text(
                        textAlign: TextAlign.center,
                        "${AppStrings.humidity.tr(context)} %",
                        style: TextStyle(
                          color: ColorManger.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const Divider(),
                Expanded(
                  child: ListView.builder(
                    itemCount: dataToShow.length * 2 - 1,
                    //   separatorBuilder: (context, index) => const Divider(),
                    itemBuilder: (context, index) {
                      if (index.isOdd) {
                        return const Divider(); // odd = divider
                      }
                      final itemIndex = index ~/ 2;
                      final msg = dataToShow[itemIndex];
                      // final msg = dataToShow[index];
                      final dateTime = DateTime(
                        msg.year,
                        msg.month,
                        msg.day,
                        msg.hour,
                        msg.minute,
                        msg.second,
                      );
                      final formattedTime = formatDateTimeByLocale(
                        dateTime,
                        locale.languageCode,
                      );
                      final weekday =
                          [
                            AppStrings.monday.tr(context),
                            AppStrings.tuesday.tr(context),
                            AppStrings.wednesday.tr(context),
                            AppStrings.thursday.tr(context),
                            AppStrings.friday.tr(context),
                            AppStrings.saturday.tr(context),
                            AppStrings.sunday.tr(context),
                          ][dateTime.weekday - 1];

                      return Row(
                        children: [
                          Expanded(
                            child: Text(
                              textAlign: TextAlign.center,
                              "$formattedTime\n$weekday",
                            ),
                          ),
                          Expanded(
                            child: Text(
                              textAlign: TextAlign.center,
                              msg.temperature.toStringAsFixed(2),
                            ),
                          ),
                          Expanded(
                            child: Text(
                              textAlign: TextAlign.center,
                              msg.humidity.toStringAsFixed(2),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
  }
}

String formatDateTimeByLocale(DateTime dateTime, String languageCode) {
  final raw = DateFormat("yyyy-MM-dd hh:mm:ss a").format(dateTime);

  if (languageCode == "ar") {
    return raw.replaceAll("AM", "صباحًا").replaceAll("PM", "مساءً");
  }

  return raw;
}
