import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/view/datalogger_main_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutBack));

    _opacityAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeIn));

    _controller.forward();

    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const DataloggerMainScreen()),
        (route) => false,
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.all(10.0.r),
        child: Center(
          child: ScaleTransition(
            scale: _scaleAnimation,
            child: FadeTransition(
              opacity: _opacityAnimation,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 25.h),
                  Image.asset('assets/images/atmoslink_stacked.png', height: 150.h),
                  SizedBox(height: 90.h),
                  Image.asset('assets/images/datalogger.png', scale: 9.sp),
                  SizedBox(height: 30.h),
                  Spacer(),
                  Padding(
                    padding: EdgeInsets.only(left: 70.w, right: 70.w),
                    child: LinearProgressIndicator(
                      minHeight: 5.h,
                      color: ColorManger.accent,
                      backgroundColor: ColorManger.primary,
                    ),
                  ),
                  SizedBox(height: 15.h),
                  Text(
                    'Loading...',
                    style: TextStyle(
                      color: ColorManger.primary,
                      fontSize: 16.sp,
                    ),
                  ),
                  SizedBox(height: 10.h),
                  Text(
                    'Powered by AtmosLink',
                    style: TextStyle(
                      color: ColorManger.primary,
                      fontSize: 14.sp,
                    ),
                  ),
                  SizedBox(height: 20.h),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
