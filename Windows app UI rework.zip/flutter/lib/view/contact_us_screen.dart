import 'package:data_logger/core/corlor_manger.dart';
import 'package:data_logger/core/app_localizations.dart';
import 'package:data_logger/core/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ContactUsPage extends StatelessWidget {
  const ContactUsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          children: [
            SizedBox(height: 40.h),
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(width: 300.w, child: _buildContactInfo(context)),
                  const SizedBox(width: 160),
                  SizedBox(width: 400.w, child: _buildImageOrMapPlaceholder()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactInfo(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppStrings.contactUs.tr(context),
          style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 24),
        _buildContactRow(
          FontAwesomeIcons.envelope,
          AppStrings.email.tr(context),
          'osama.kamal@dakahlia.net',
        ),
        const SizedBox(height: 16),
        _buildContactRow(
          FontAwesomeIcons.phone,
          AppStrings.phone.tr(context),
          '+201066375339',
        ),
        const SizedBox(height: 16),
        _buildContactRow(
          FontAwesomeIcons.mapMarkerAlt,
          "15th Ramo Bldgs, 9th floor",
          AppStrings.addressDeatils.tr(context),
        ),
        const SizedBox(height: 16),
        _buildContactRow(
          FontAwesomeIcons.globe,
          AppStrings.website.tr(context),
          'http://www.dakahlia.com',
        ),
        const SizedBox(height: 32),
        Text(
          AppStrings.workingHours.tr(context),
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(AppStrings.workingHoursValue.tr(context)),
        Text(AppStrings.workingHoursValue2.tr(context)),
      ],
    );
  }

  Widget _buildContactRow(IconData icon, String title, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 24, color: ColorManger.accent),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontSize: 16)),
          ],
        ),
      ],
    );
  }

  Widget _buildImageOrMapPlaceholder() {
    return Column(
      children: [
        Opacity(
          opacity: 0.4,
          child: Image.asset("assets/images/atmoslink_stacked.png", fit: BoxFit.contain),
        ),
        SizedBox(height: 40),
        Image.asset('assets/images/datalogger.png', scale: 9),
      ],
    );
  }
}
