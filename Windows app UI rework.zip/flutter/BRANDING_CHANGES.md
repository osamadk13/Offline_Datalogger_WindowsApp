# AtmosLink rebrand

Drop these files over the original `datelogger-main` repo (same paths), then commit.

## Changed
- lib/core/corlor_manger.dart — brand colors: primary #123E70, primaryLight #EAF0F7, accent #2E9CC2
- All Colors.blue / blue.shadeX / blueAccent in lib/ -> ColorManger.primary / primaryLight / accent (22 files)
- sidebar.dart — AtmosLink horizontal logo (width 170)
- splash_screen.dart — AtmosLink stacked logo, teal progress bar, "Powered by AtmosLink"
- contact_us_screen.dart — AtmosLink stacked logo
- pdf_report.dart, export_chart_to_pdf.dart — PDF watermark/logo -> AtmosLink
- assets/images/atmoslink_{horizontal,stacked,mark}.png (new) + pubspec.yaml asset entries
- windows/runner/resources/app_icon.ico — AtmosLink mark (16/32/48/256)
- windows/runner/Runner.rc — CompanyName / ProductName / copyright -> AtmosLink

## Not changed (confirm)
- Contact page email/website still point to dakahlia.net / dakahlia.com
- assets/images/datalogger.png (product photo shows testo devices)

## Push to a new GitHub repo
```
cd datelogger-main
# copy the contents of this folder over the repo, then:
git checkout -b atmoslink-rebrand
git add -A && git commit -m "Rebrand to AtmosLink"
gh repo create atmoslink-datalogger --private --source=. --push
```
